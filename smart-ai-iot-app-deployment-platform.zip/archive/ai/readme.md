## Running Instructions
#### Step 1: `sudo docker build -t aimanager:latest . `
#### Step 2: `sudo docker run -p 6000:6000 -p 6001:6001 aimanager`
#### Step 3: `python3 dataScientist.py`
#### Step 4: `python3 client.py`
