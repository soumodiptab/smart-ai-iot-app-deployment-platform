## Running Instructions
#### Step 1: `sudo docker build -t aimanager:latest . `
#### Step 2: `sudo docker run -p 6500:6500 aimanager`
