# Logger

Will contain logstash configuration files