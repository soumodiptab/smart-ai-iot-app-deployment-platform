# smart-ai-iot-app-deployment-platform
Distributed Microservices based Platform to Manage entire lifecycle of 
