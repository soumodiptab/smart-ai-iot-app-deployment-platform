import socket,ssl
while True:
    host=input("Enter hostname : ")
    hostji=host
    urlji=input("Enter URL : ")
    x=urlji.find('/')
    urlji=urlji[x:]
    host=socket.gethostbyname(host)
    port=443
    context=ssl.SSLContext()
    s=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    ssl_sock=context.wrap_socket(s,server_hostname=host)
    ssl_sock.connect((host,port))
    request="GET /"+urlji+" HTTP/1.1\r\nHost: "+hostji+"\r\n\r\n"
    ssl_sock.sendall(request.encode())


    data=ssl_sock.recv(10240)
    if(len(data)<1):
        print("error")
    data=data.decode(errors='ignore')
    temp=data.lower()
    x=temp.find("<!doctype html>")
    print(data[x:])
    


    while True:
        data=ssl_sock.recv(2048)
        if(len(data)<1):
            break
        print(data.decode(errors='ignore'))

    ssl_sock.close()
