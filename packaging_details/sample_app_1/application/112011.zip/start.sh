#!/bin/bash
python3 app.py
python3 config/script1.py