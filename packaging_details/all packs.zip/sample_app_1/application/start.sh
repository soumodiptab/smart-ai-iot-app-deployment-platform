cp scripts/script1.py script1.py
python3 script1.py
rm script1.py